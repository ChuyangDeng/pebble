PEBBLEKIT JS MESSAGE KEYS
Key Name	|	Key ID
standby 	|	0
hello_msg	|	1
showF		|	2
showAvg		|	3
showMin		|	4
showMax		|	5
ulong_msg	|	6
dlong_msg	|	7
click		|	8
auto		|	9
predict		|	10